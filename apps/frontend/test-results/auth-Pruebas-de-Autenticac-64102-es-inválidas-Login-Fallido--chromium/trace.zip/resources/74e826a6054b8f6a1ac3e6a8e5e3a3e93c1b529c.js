(globalThis["TURBOPACK_CHUNK_LISTS"] || (globalThis["TURBOPACK_CHUNK_LISTS"] = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: ["static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_0wwxod.._.js","static/chunks/04-8_next_dist_compiled_next-devtools_index_0zdoccd.js","static/chunks/04-8_next_dist_compiled_react-dom_0mmu_9v._.js","static/chunks/04-8_next_dist_compiled_react-server-dom-turbopack_09jsga6._.js","static/chunks/04-8_next_dist_compiled_08ytvqf._.js","static/chunks/04-8_next_dist_client_0tif~gq._.js","static/chunks/04-8_next_dist_129z_gj._.js","static/chunks/0i4a_@swc_helpers_cjs_0hvz.20._.js"],
    source: "entry"
});
