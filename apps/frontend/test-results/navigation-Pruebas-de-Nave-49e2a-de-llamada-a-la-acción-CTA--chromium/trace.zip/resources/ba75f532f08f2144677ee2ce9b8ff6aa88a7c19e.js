(globalThis["TURBOPACK_CHUNK_LISTS"] || (globalThis["TURBOPACK_CHUNK_LISTS"] = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: ["static/chunks/node_modules__pnpm_0lho5qv._.js","static/chunks/apps_frontend_src_00y6k60._.js"],
    source: "dynamic"
});
