(globalThis["TURBOPACK_CHUNK_LISTS"] || (globalThis["TURBOPACK_CHUNK_LISTS"] = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: ["static/chunks/[root-of-the-server]__0.59wcw._.css","static/chunks/node_modules__pnpm_0sf5zmn._.js","static/chunks/apps_frontend_src_components_ThemeProvider_tsx_0kwdw1r._.js"],
    source: "dynamic"
});
