(globalThis["TURBOPACK_CHUNK_LISTS"] || (globalThis["TURBOPACK_CHUNK_LISTS"] = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: ["static/chunks/apps_frontend_src_04i1~ac._.js","static/chunks/0995_tailwind-merge_dist_bundle-mjs_mjs_0osztqy._.js","static/chunks/0qc8_recharts_es6_util_05ukhxe._.js","static/chunks/0qc8_recharts_es6_state_0b26u9c._.js","static/chunks/0qc8_recharts_es6_component_0q1htou._.js","static/chunks/0qc8_recharts_es6_cartesian_0yawp0d._.js","static/chunks/0qc8_recharts_es6_0dvgvp3._.js","static/chunks/node_modules__pnpm_13klp--._.js"],
    source: "dynamic"
});
