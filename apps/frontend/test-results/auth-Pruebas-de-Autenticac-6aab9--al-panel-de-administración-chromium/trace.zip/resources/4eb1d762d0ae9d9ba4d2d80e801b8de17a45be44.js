(globalThis["TURBOPACK_CHUNK_LISTS"] || (globalThis["TURBOPACK_CHUNK_LISTS"] = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: ["static/chunks/node_modules__pnpm_0x-q5sf._.js","static/chunks/apps_frontend_src_04i1~ac._.js"],
    source: "dynamic"
});
