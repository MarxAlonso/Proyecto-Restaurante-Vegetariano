(globalThis["TURBOPACK_CHUNK_LISTS"] || (globalThis["TURBOPACK_CHUNK_LISTS"] = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: ["static/chunks/[root-of-the-server]__0.59wcw._.css","static/chunks/node_modules__pnpm_07p10n~._.js","static/chunks/apps_frontend_src_06rp_de._.js"],
    source: "dynamic"
});
